using AppWorkflow.Common.Enums;
using System.Text.Json;

namespace AppWorkflow.Data;

public class WorkflowData
    {
        public Guid Id { get; set; }
        public Guid WorkflowId { get; set; }
        public string WorkflowVersion { get; set; }
        public WorkflowStatus Status { get; set; }
        public Guid CurrentStepId { get; set; }
        public JsonDocument ModuleData { get; set; }
        public Dictionary<string, object> Variables { get; set; } = new();
        public List<WorkflowStepData> StepInstances { get; set; } = new();
        public DateTime StartedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public string ErrorDetails { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string UpdatedBy { get; set; }
        public bool IsDeleted { get; set; }
        public string AuditLog { get; set; }

        public virtual ICollection<WorkflowRelation> ParentRelations { get; set; } = new List<WorkflowRelation>();
        public virtual ICollection<WorkflowRelation> ChildRelations { get; set; } = new List<WorkflowRelation>();
}