namespace AppWorkflow.Schema;

public class StepTransition
    {
        public Guid SourceStepId { get; set; }
        public Guid TargetStepId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Condition { get; set; }
        public int Priority { get; set; }
        public Dictionary<string, string> Metadata { get; set; } = new();
    }