namespace AppWorkflow.Engine;

public interface IExpressionEvaluator
    {
    }