namespace AppWorkflow.Infrastructure.Data.Context;

using AppWorkflow.Core.Domain.Data;
using AppWorkflow.Core.Domain.Schema;
using AppWorkflow.Infrastructure.Data.Configurations;
using Microsoft.EntityFrameworkCore;

public class WorkflowDbContext : DbContext
    {
    public WorkflowDbContext(DbContextOptions<WorkflowDbContext> options) : base(options)
    {
    }
  
    public DbSet<Workflow> Workflows { get; set; }
        public DbSet<ApprovalRequest> ApprovalRequests { get; set; }
        public DbSet<ApprovalHistory> ApprovalHistories { get; set; }
        public DbSet<WorkflowData> WorkflowDatas { get; set; }
        public DbSet<WorkflowStep> WorkflowSteps { get; set; }
        public DbSet<WorkflowStepData> WorkflowStepInstances { get; set; }
        public DbSet<WorkflowVariable> WorkflowVariables { get; set; }
        public DbSet<WorkflowCheckpoint> WorkflowCheckpoints { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }
        public DbSet<SynchronizationPoint> SynchronizationPoints { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
             base.OnModelCreating(modelBuilder);
            
        modelBuilder.ConfigureWorkflowRelations();
        modelBuilder.ApplyConfiguration(new ApprovalConfiguration());
        modelBuilder.ApplyConfiguration(new ApprovalHistoryConfiguration());
            // Add similar configurations for other entities...
        }
    }